/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package farmaciapoo;

import java.sql.Statement;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;



public class Medicamentos extends javax.swing.JFrame {

    /**
     * Creates new form Medicamentos
     */
    public Medicamentos() {
        initComponents();
        SelecMedicamentos();
    }
    Connection Con = null;
    Statement St = null;
    ResultSet Rs = null;/*
    /*java.util.Date CDate, EDate;
    java.sql.Date MyCDate, MyEDate;  */ 

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        nombre = new javax.swing.JTextField();
        codigo_barras = new javax.swing.JTextField();
        precio = new javax.swing.JTextField();
        cantidad_stock = new javax.swing.JTextField();
        fecha_creacion = new com.toedter.calendar.JDateChooser();
        fecha_vencimiento = new com.toedter.calendar.JDateChooser();
        Add_btn = new javax.swing.JButton();
        Update_btn = new javax.swing.JButton();
        Delete_boton = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        MedicamentosTabla = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        Clear_btn = new javax.swing.JButton();
        Vendedor_btn = new javax.swing.JLabel();
        Proveedor_btn = new javax.swing.JLabel();
        Ventas_btn = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(187, 187, 187));
        jPanel1.setForeground(new java.awt.Color(60, 63, 65));

        jPanel2.setBackground(new java.awt.Color(51, 51, 255));

        jLabel7.setFont(new java.awt.Font("Noto Sans", 1, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("CODIGO DE BARRAS");

        jLabel8.setFont(new java.awt.Font("Noto Sans", 1, 16)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("NOMBRE");

        jLabel9.setFont(new java.awt.Font("Noto Sans", 1, 16)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("PRECIO");

        jLabel10.setFont(new java.awt.Font("Noto Sans", 1, 16)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("CANTIDAD");

        jLabel11.setFont(new java.awt.Font("Noto Sans", 1, 16)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("FECHAFAB");

        jLabel12.setFont(new java.awt.Font("Noto Sans", 1, 16)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("FECHAEXP");

        nombre.setBackground(new java.awt.Color(187, 187, 187));
        nombre.setForeground(new java.awt.Color(70, 73, 75));
        nombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nombreActionPerformed(evt);
            }
        });

        codigo_barras.setBackground(new java.awt.Color(187, 187, 187));
        codigo_barras.setForeground(new java.awt.Color(70, 73, 75));
        codigo_barras.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                codigo_barrasActionPerformed(evt);
            }
        });

        precio.setBackground(new java.awt.Color(187, 187, 187));
        precio.setForeground(new java.awt.Color(70, 73, 75));
        precio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                precioActionPerformed(evt);
            }
        });

        cantidad_stock.setBackground(new java.awt.Color(187, 187, 187));
        cantidad_stock.setForeground(new java.awt.Color(70, 73, 75));
        cantidad_stock.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cantidad_stockActionPerformed(evt);
            }
        });

        Add_btn.setBackground(new java.awt.Color(187, 187, 187));
        Add_btn.setFont(new java.awt.Font("Open Sans", 1, 14)); // NOI18N
        Add_btn.setForeground(new java.awt.Color(78, 80, 82));
        Add_btn.setText("AGREGAR");
        Add_btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Add_btnMouseClicked(evt);
            }
        });
        Add_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Add_btnActionPerformed(evt);
            }
        });

        Update_btn.setBackground(new java.awt.Color(187, 187, 187));
        Update_btn.setFont(new java.awt.Font("Open Sans", 1, 14)); // NOI18N
        Update_btn.setForeground(new java.awt.Color(78, 80, 82));
        Update_btn.setText("ACTUALIZAR");
        Update_btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Update_btnMouseClicked(evt);
            }
        });
        Update_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Update_btnActionPerformed(evt);
            }
        });

        Delete_boton.setBackground(new java.awt.Color(187, 187, 187));
        Delete_boton.setFont(new java.awt.Font("Open Sans", 1, 14)); // NOI18N
        Delete_boton.setForeground(new java.awt.Color(78, 80, 82));
        Delete_boton.setText("BORRAR");
        Delete_boton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Delete_botonActionPerformed(evt);
            }
        });

        MedicamentosTabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "CODIGOBARRAS", "NOMBRE", "PRECIO", "CANTIDAD", "FECHAFAB", "FECHAEXP"
            }
        ));
        MedicamentosTabla.setSelectionBackground(new java.awt.Color(187, 187, 187));
        MedicamentosTabla.setSelectionForeground(new java.awt.Color(15, 42, 61));
        MedicamentosTabla.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                MedicamentosTablaMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(MedicamentosTabla);

        jLabel5.setFont(new java.awt.Font("Cantarell", 1, 28)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("X");
        jLabel5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel5MouseClicked(evt);
            }
        });

        jLabel13.setFont(new java.awt.Font("Noto Sans", 1, 24)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("ADMINISTRACION DE MEDICAMENTOS");

        jLabel4.setFont(new java.awt.Font("Cantarell", 2, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Lista de Medicamentos");

        Clear_btn.setBackground(new java.awt.Color(187, 187, 187));
        Clear_btn.setFont(new java.awt.Font("Open Sans", 1, 14)); // NOI18N
        Clear_btn.setForeground(new java.awt.Color(78, 80, 82));
        Clear_btn.setText("LIMPIAR");
        Clear_btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Clear_btnMouseClicked(evt);
            }
        });
        Clear_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Clear_btnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(143, 143, 143)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(precio, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(373, 373, 373)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel11)
                                    .addComponent(jLabel12))))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel10)
                            .addComponent(jLabel8)
                            .addComponent(jLabel9))
                        .addGap(32, 32, 32)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel13)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(Add_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(30, 30, 30)
                                .addComponent(Update_btn)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(Delete_boton, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(23, 23, 23))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(cantidad_stock, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(nombre, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE)))))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(fecha_creacion, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(fecha_vencimiento, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Clear_btn, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(223, 223, 223))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addGap(148, 148, 148))))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(44, 44, 44)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 743, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(276, 276, 276)
                        .addComponent(jLabel4)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel2Layout.createSequentialGroup()
                    .addGap(144, 144, 144)
                    .addComponent(codigo_barras, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(677, Short.MAX_VALUE)))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(90, 90, 90)
                        .addComponent(jLabel7)
                        .addGap(26, 26, 26))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel13)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(fecha_creacion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel11))))
                .addGap(8, 8, 8)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(nombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addGap(27, 27, 27)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel9)
                        .addComponent(precio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel12))
                    .addComponent(fecha_vencimiento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(cantidad_stock, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(50, 50, 50)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Add_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Update_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Delete_boton, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Clear_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 34, Short.MAX_VALUE)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35))
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel2Layout.createSequentialGroup()
                    .addGap(87, 87, 87)
                    .addComponent(codigo_barras, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(497, Short.MAX_VALUE)))
        );

        Vendedor_btn.setFont(new java.awt.Font("Noto Sans", 1, 18)); // NOI18N
        Vendedor_btn.setForeground(new java.awt.Color(0, 0, 0));
        Vendedor_btn.setText("USUARIOS");
        Vendedor_btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Vendedor_btnMouseClicked(evt);
            }
        });

        Proveedor_btn.setFont(new java.awt.Font("Noto Sans", 1, 18)); // NOI18N
        Proveedor_btn.setForeground(new java.awt.Color(0, 0, 0));
        Proveedor_btn.setText("PROVEEDOR");
        Proveedor_btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Proveedor_btnMouseClicked(evt);
            }
        });

        Ventas_btn.setFont(new java.awt.Font("Noto Sans", 1, 18)); // NOI18N
        Ventas_btn.setForeground(new java.awt.Color(0, 0, 0));
        Ventas_btn.setText("VENTAS");
        Ventas_btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Ventas_btnMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Vendedor_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Ventas_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Proveedor_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 829, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(105, 105, 105)
                .addComponent(Proveedor_btn)
                .addGap(38, 38, 38)
                .addComponent(Vendedor_btn)
                .addGap(42, 42, 42)
                .addComponent(Ventas_btn)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 957, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    public void SelecMedicamentos(){
        try {
            Con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/farmacia_db", "poo2024", "admin2024");
            /*PreparedStatement add = Con.prepareStatement("SELECT * from poo2024.medicamentos");*/
            St = Con.createStatement();
            Rs = St.executeQuery("""
                                 SELECT codigo_barras, 
                                        nombre, 
                                        precio, 
                                        cantidad_stock, 
                                        fecha_creacion, 
                                        fecha_vencimiento
                                 FROM medicamentos;""");
            MedicamentosTabla.setModel(DbUtils.resultSetToTableModel(Rs));
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    private void nombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nombreActionPerformed

    private void codigo_barrasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_codigo_barrasActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_codigo_barrasActionPerformed

    private void precioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_precioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_precioActionPerformed

    private void cantidad_stockActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cantidad_stockActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cantidad_stockActionPerformed

    private void Add_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Add_btnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Add_btnActionPerformed

    private void Update_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Update_btnActionPerformed
        // TODO add your handling code here:
        try {
            Con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/farmacia_db", "poo2024", "admin2024");
            PreparedStatement add = Con.prepareStatement("UPDATE medicamentos SET codigo_barras=?, nombre = ?, precio = ?, cantidad_stock = ?, fecha_creacion = ?, fecha_vencimiento = ? WHERE codigos_barras = ?");
            
            add.setString(1, codigo_barras.getText());
            add.setString(2, nombre.getText());  
            add.setDouble(3, Double.parseDouble(precio.getText()));
            add.setInt(4, Integer.parseInt(cantidad_stock.getText()));

            java.sql.Date sqlFechaCreacion = new java.sql.Date(fecha_creacion.getDate().getTime());
            java.sql.Date sqlFechaVencimiento = new java.sql.Date(fecha_vencimiento.getDate().getTime());

            add.setDate(5, sqlFechaCreacion);
            add.setDate(6, sqlFechaVencimiento);
         
            add.executeUpdate();
            Con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        
    }  
    }//GEN-LAST:event_Update_btnActionPerformed

    private void Delete_botonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Delete_botonActionPerformed
        // TODO add your handling code here:
        if (codigo_barras.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this,"Ingrese el Medicamento a borrar");
            
        } else {
            try {
                Con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/farmacia_db", "poo2024", "admin2024");
                String Id = codigo_barras.getText();
                String Query = "Delete from medicamentos where codigo_barras='"+ Id +"'";
                Statement Add = Con.createStatement();
                Add.executeUpdate(Query);
                SelecMedicamentos();
                JOptionPane.showMessageDialog(this,"Medicamento borrado con exito");
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }//GEN-LAST:event_Delete_botonActionPerformed
   
    private void Add_btnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Add_btnMouseClicked
    
      try {
            Con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/farmacia_db", "poo2024", "admin2024");
            PreparedStatement add = Con.prepareStatement("INSERT INTO medicamentos (codigo_barras, nombre, precio, cantidad_stock, fecha_creacion, fecha_vencimiento) VALUES (?, ?, ?, ?, ?, ?)");
            add.setString(1, codigo_barras.getText());
            add.setString(2, nombre.getText());  
            add.setDouble(3, Double.parseDouble(precio.getText()));
            add.setInt(4, Integer.parseInt(cantidad_stock.getText()));

            java.sql.Date sqlFechaCreacion = new java.sql.Date(fecha_creacion.getDate().getTime());
            java.sql.Date sqlFechaVencimiento = new java.sql.Date(fecha_vencimiento.getDate().getTime());

            add.setDate(5, sqlFechaCreacion);
            add.setDate(6, sqlFechaVencimiento);
         
            add.executeUpdate();
            JOptionPane.showMessageDialog(this,"Medicamento agregado exitosamente");
                   
            Con.close();
            SelecMedicamentos();
            
        } catch (SQLException e) {
            e.printStackTrace();
        
    }//GEN-LAST:event_Add_btnMouseClicked
}
    private void MedicamentosTablaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MedicamentosTablaMouseClicked
        // TODO add your handling code here:
        DefaultTableModel model =(DefaultTableModel)MedicamentosTabla.getModel();
        int Myindex = MedicamentosTabla.getSelectedRow();
        if (Myindex != -1){
        codigo_barras.setText(model.getValueAt(Myindex, 0).toString());
        nombre.setText(model.getValueAt(Myindex, 1).toString());
        precio.setText(model.getValueAt(Myindex, 2).toString());
        cantidad_stock.setText(model.getValueAt(Myindex, 3).toString());
        }
    }//GEN-LAST:event_MedicamentosTablaMouseClicked

    private void Update_btnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Update_btnMouseClicked
        // TODO add your handling code here:
        if (codigo_barras.getText().isEmpty()|| nombre.getText().isEmpty()||precio.getText().isEmpty()||cantidad_stock.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this,"Informacion necesaria");
        }else if (fecha_creacion.getDate() == null || fecha_vencimiento.getDate() == null) {
        // Verificar si las fechas están vacías
        JOptionPane.showMessageDialog(this, "Debe seleccionar las fechas de creación y vencimiento.");
            
        } else {
            try {
                java.sql.Date sqlFechaCreacion = new java.sql.Date(fecha_creacion.getDate().getTime());
                java.sql.Date sqlFechaVencimiento = new java.sql.Date(fecha_vencimiento.getDate().getTime());
                
                Con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/farmacia_db", "poo2024", "admin2024");
                // Consulta SQL usando PreparedStatement
                String UpdateQuery = "UPDATE medicamentos SET nombre = ?, precio = ?, cantidad_stock = ?, fecha_creacion = ?, fecha_vencimiento = ? WHERE codigo_barras = ?";
                PreparedStatement pstmt = Con.prepareStatement(UpdateQuery);

                // Asignar valores a los parámetros
                pstmt.setString(1, nombre.getText()); // nombre
                pstmt.setDouble(2, Double.parseDouble(precio.getText())); // precio (convertir a double)
                pstmt.setInt(3, Integer.parseInt(cantidad_stock.getText())); // cantidad_stock (convertir a int)
                pstmt.setDate(4, sqlFechaCreacion); // fecha_creacion
                pstmt.setDate(5, sqlFechaVencimiento); // fecha_vencimiento
                pstmt.setString(6, codigo_barras.getText().trim()); // codigo_barras

                // Ejecutar la consulta
                pstmt.executeUpdate();
                JOptionPane.showMessageDialog(this,"Medicamento actualizado exitosamente");
            } catch (SQLException e) {
            }
            SelecMedicamentos();
        }
    }//GEN-LAST:event_Update_btnMouseClicked

    private void Clear_btnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Clear_btnMouseClicked
        // TODO add your handling code here:
        codigo_barras.setText("");
        nombre.setText("");
        precio.setText("");
        cantidad_stock.setText("");
    }//GEN-LAST:event_Clear_btnMouseClicked

    private void Clear_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Clear_btnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Clear_btnActionPerformed

    private void Proveedor_btnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Proveedor_btnMouseClicked
        // TODO add your handling code here:
        new Proveedor().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_Proveedor_btnMouseClicked

    private void Vendedor_btnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Vendedor_btnMouseClicked
        // TODO add your handling code here:
        new Usuarios().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_Vendedor_btnMouseClicked

    private void Ventas_btnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Ventas_btnMouseClicked
        // TODO add your handling code here:
        new Venta().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_Ventas_btnMouseClicked

    private void jLabel5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel5MouseClicked
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_jLabel5MouseClicked


    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Medicamentos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Medicamentos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Medicamentos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Medicamentos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Medicamentos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Add_btn;
    private javax.swing.JButton Clear_btn;
    private javax.swing.JButton Delete_boton;
    private javax.swing.JTable MedicamentosTabla;
    private javax.swing.JLabel Proveedor_btn;
    private javax.swing.JButton Update_btn;
    private javax.swing.JLabel Vendedor_btn;
    private javax.swing.JLabel Ventas_btn;
    private javax.swing.JTextField cantidad_stock;
    private javax.swing.JTextField codigo_barras;
    private com.toedter.calendar.JDateChooser fecha_creacion;
    private com.toedter.calendar.JDateChooser fecha_vencimiento;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField nombre;
    private javax.swing.JTextField precio;
    // End of variables declaration//GEN-END:variables
}
